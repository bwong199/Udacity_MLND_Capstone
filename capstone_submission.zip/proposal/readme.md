in the command line if you have jupyter notebook installed

the project runs in Python2

You should have sci-kit learn, numpy, panda and matplotlib installed

run jupyter notebook capstone.ipynb in this directory.

The documentation is in Udacity Machine Learning Nanodegree Capstone Project Submission.

